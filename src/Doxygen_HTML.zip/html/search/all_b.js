var searchData=
[
  ['observer',['Observer',['../class_observer.html',1,'']]],
  ['observers',['observers',['../class_time_wizard.html#a1c27337e5a42444c9e092ae384bb665d',1,'TimeWizard']]],
  ['ourcolors',['OurColors',['../namespace_our_colors.html',1,'']]]
];
