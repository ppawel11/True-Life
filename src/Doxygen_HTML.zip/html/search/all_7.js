var searchData=
[
  ['herbivore',['Herbivore',['../class_herbivore.html',1,'']]],
  ['howfaris',['howFarIs',['../class_animal.html#a3a52a94772d339e5003264eee73b289d',1,'Animal']]]
];
