var searchData=
[
  ['ui',['Ui',['../namespace_ui.html',1,'']]],
  ['update',['update',['../class_environment.html#a4fbbc89300ce2d35c8f1e0d674213b98',1,'Environment::update(boost::shared_ptr&lt; EnvDataModel &gt;)'],['../class_environment.html#adb25da21b94ec2dd2776e9bede3da56f',1,'Environment::update(int id)'],['../class_observer.html#a405bc6cd4b1f3556422e3541eea9d97b',1,'Observer::update(boost::shared_ptr&lt; EnvDataModel &gt;)'],['../class_observer.html#ae8bd0d25de40f933b5ba0b5fefee95fc',1,'Observer::update(int id)'],['../class_observer.html#a1911b9f673aa3d52558c61c2fb04f1f5',1,'Observer::update(StatisticsModel *)'],['../class_simu_widget.html#a8298dd79c81d1e34946dd6d81390197b',1,'SimuWidget::update()']]],
  ['updateanimals',['updateAnimals',['../class_environment.html#a5dc527aeeffb7af8c1d2c66f91a9d56c',1,'Environment']]],
  ['updatestats',['updateStats',['../class_stat_widget.html#a759fe930239cbc856b304dcd75ee6832',1,'StatWidget']]]
];
