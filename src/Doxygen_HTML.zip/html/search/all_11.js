var searchData=
[
  ['velo_5fx',['velo_x',['../class_animal.html#a4dfbf1b7f35dbd7c1ae1387a59f5bf8e',1,'Animal']]],
  ['view_5frange',['view_range',['../class_animal.html#a6302f47e81427d8d774efa5f22a6d548',1,'Animal']]]
];
