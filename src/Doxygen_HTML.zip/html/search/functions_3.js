var searchData=
[
  ['die',['die',['../class_animal.html#a557fe0d71dda75be2f8459ce0d7c2275',1,'Animal']]]
];
