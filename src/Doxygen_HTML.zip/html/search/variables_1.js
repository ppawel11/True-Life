var searchData=
[
  ['clicked_5faction',['clicked_action',['../class_simu_ellipse.html#a52da5409baad08bb79bef75bcfb1a86e',1,'SimuEllipse']]]
];
