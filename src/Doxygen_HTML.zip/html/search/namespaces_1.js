var searchData=
[
  ['foo',['Foo',['../namespace_foo.html',1,'']]]
];
