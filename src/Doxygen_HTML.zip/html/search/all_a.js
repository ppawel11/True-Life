var searchData=
[
  ['new_5fborns',['new_borns',['../class_environment.html#afadd48b9387ac42f246c88f35cd21571',1,'Environment']]]
];
