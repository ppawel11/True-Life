var searchData=
[
  ['ready_5fcooldown',['ready_cooldown',['../class_animal.html#a19aa8edec30efc18ac97637b3b820cef',1,'Animal']]],
  ['reduceenergy',['reduceEnergy',['../class_animal.html#a90d69ae288e14534ded4b57f97807098',1,'Animal']]],
  ['reducereadycooldown',['reduceReadyCooldown',['../class_animal.html#a06ddd80ab974bdb7b90ef98a5720810c',1,'Animal']]],
  ['resetfollow',['resetFollow',['../class_animal.html#aca199b5fcf5173d877883994e98125ae',1,'Animal']]],
  ['resetreadycooldown',['resetReadyCooldown',['../class_animal.html#a2093a02352befe082f57201a1568f8a4',1,'Animal']]]
];
