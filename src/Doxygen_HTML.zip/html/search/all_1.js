var searchData=
[
  ['beeaten',['beEaten',['../class_herbivore.html#a05f2fa539405abaf6ffb43fdf07dcbca',1,'Herbivore']]],
  ['beeeaten',['beEeaten',['../class_food.html#a7dc5689c92591040459eaafc017671d2',1,'Food']]]
];
